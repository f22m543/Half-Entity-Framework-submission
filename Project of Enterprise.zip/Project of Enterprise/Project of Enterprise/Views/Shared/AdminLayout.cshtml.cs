using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Project_of_Enterprise.Views.Shared
{
    public class AdminLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
